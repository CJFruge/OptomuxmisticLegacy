/*
 * SerialIOSync.java
 *
 * Created on April 23, 2007, 2:08 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 *
 * @author cjf
 */

package com.ssi.lib.comm;

import gnu.io.*;
import java.io.*;
import java.util.*;

public class SerialIOSync {

    private CommPortIdentifier portId = null;
    private InputStream inputStream = null;
    private OutputStream outputStream = null;
    private SerialPort serialPort = null;
    private StringBuilder response = new StringBuilder();
    private long msTimeOut = 2000;
    private String data = new String();
    private String m_comPortName;
    private int m_baudRate;
    private int m_dataBits;
    private int m_stopBits;
    private int m_parity;
    private boolean m_RTSCTS;
    
    public static void main(String[] args) {
        try {
            SerialIOSync sio = new SerialIOSync(args[0],38400,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE,true);
        }
        catch (Exception e) { System.err.println(e); }
    }
    
    public SerialIOSync(String comPortName, int baudRate, int dataBits, int stopBits, int parity, boolean RTS_CTS) throws Exception {

	m_comPortName = comPortName;
	m_baudRate = baudRate;
	m_dataBits = dataBits;
	m_stopBits = stopBits;
	m_parity = parity;
	
	try {
	    openPort();
	    resetPort(false);
	} catch (Exception e) { throw e; }
    }
 
    public SerialIOSync(String comPortName) throws Exception {
	
	m_comPortName = comPortName;
	
	try {
	    openPort();
	    resetPort(false);
	} catch (Exception e) { throw e; }
    }

    private void openPort() throws Exception {
	
	try {
            portId = CommPortIdentifier.getPortIdentifier(m_comPortName);
            serialPort = (SerialPort) portId.open(this.getClass().getName(), 2000);
        } catch (PortInUseException e) { 
	    e.printStackTrace(); 
	    throw e; 
	}

        try {
            inputStream = serialPort.getInputStream();
            outputStream = serialPort.getOutputStream();
        } catch (IOException e) { 
            if ( portId.isCurrentlyOwned() ) { serialPort.close(); }
            e.printStackTrace(); 
            throw e; 
        }
    }

    public void resetPort(boolean fullReset) throws Exception {
        
	if ( fullReset ) {
	    closePort();
	    openPort();
	}
	try {
            serialPort.setSerialPortParams(m_baudRate,m_dataBits,m_stopBits,m_parity);
            serialPort.setDTR(false);
            serialPort.setRTS(m_RTSCTS);
        } catch (UnsupportedCommOperationException e) {
            if ( portId.isCurrentlyOwned() ) { serialPort.close(); }
            e.printStackTrace(); 
            throw e; 
        }
    }
    
    protected void finalize() { 
        try {
            super.finalize(); closePort(); 
        } catch (Throwable e) { e.printStackTrace(); }
    }
    
    public void closePort() { if ( portId.isCurrentlyOwned() ) serialPort.close(); }
    
    public void getChars () throws IOException {
        byte[] readBuff = {0};
        int charAvail;
        response.delete(0,response.length());
        long ts = Calendar.getInstance().getTimeInMillis();
        try {
            while ( readBuff[readBuff.length-1] != '\r' ) {
                charAvail = inputStream.available();
                if ( charAvail > 0 ) {
                    readBuff = new byte[charAvail];
                    inputStream.read(readBuff);
                    response.append(new String(readBuff));
                }
                if ( Calendar.getInstance().getTimeInMillis() > (ts + msTimeOut) ) {
                    response.delete(0,response.length());
                    response.append("TIMEOUT");
                    break;
                }
            }
        } catch (IOException e) { e.printStackTrace(); throw e; }         
        data = response.substring(0);
    }
    
    public void transmitData(String data) throws IOException {
        try {
            byte[] outBytes = data.getBytes();
            outputStream.write(outBytes,0,outBytes.length);                
        } catch ( IOException e ) { e.printStackTrace(); throw e; }            
    }

    public void setBaudRate(int baudRate)   { m_baudRate = baudRate; }
    public void setDataBits(int dataBits)   { m_dataBits = dataBits; }
    public void setStopBits(int stopBits)   { m_stopBits = stopBits; }
    public void setParity(int parity)	    { m_parity = parity; }
    public void setRtsCtsOn(boolean b)	    { m_RTSCTS = b; }
    public void setTimeOut(long newMsTimeOut) { msTimeOut = newMsTimeOut; }
    
    public int getBaudRate()	    { return m_baudRate; }
    public int getDataBits()	    { return m_dataBits; }
    public int getStopBits()	    { return m_stopBits; }
    public int getParity()	    { return m_parity; }
    public boolean getRtsCtsOn()    { return m_RTSCTS; }
    public String getCharString()   { return data; }
    
} //*~
